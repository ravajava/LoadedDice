﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LoadedDice2;
namespace LoginProject
{
    public partial class LoginForm : Form
    {

        public string nameCheck;


        public LoginForm()
        {
            InitializeComponent();
        }

   

        private void enterButton_Click(object sender, EventArgs e)
        {
            LoadedDice2.MainMenu playerMenu = new LoadedDice2.MainMenu(loginBox.Text);
            playerMenu.ShowDialog();
            DialogResult = DialogResult.OK;
            Close();
        }
    }
}
