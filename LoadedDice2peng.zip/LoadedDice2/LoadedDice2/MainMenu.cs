﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace LoadedDice2
{

    public enum FACTIONS
    {
        ALLEROD,
        ARCEA,
        AZTLAN,
        CAMBRIA,
        DAHOMEY,
        DOTHA,
        ENSHAW,
        EPHESUS,
        HOFFNUNG_STATE,
        HIJJIA,
        IMANIA,
        KARELIA,
        MARTIANAS,
        MAYAYORE,
        NORTH_GURRKHA,
        ORISSCA,
        SEABRING,
        SOUTH_ARCEA,
        SCARABEEN,
        SHIRUDO,
        WHITE_FOREST,
        WAR_LORD,
        NO_FACTION

    }
    public partial class MainMenu : Form
    {

        public Dictionary<int, FactionObject> ListOfFactions = new Dictionary<int, FactionObject>();
        public string pName;
        public MainMenu()
        {
            InitializeComponent();

        }
        public MainMenu(string aName)
        {
            InitializeComponent();
            pName = aName;

            int i = 0;
            CheckFile();
            //I know that reading from a string file is not preferred, but in this case, it's relatively easy and makes adding new players easier, imo
            foreach (string line in File.ReadLines("../../../Files/users.txt", Encoding.UTF8))
            {

                if (line == pName)
                {

                    GeneratePlayerList(i, pName);
                    break;
                }

                i++;

            }


        }

        private void submitButton_Click(object sender, EventArgs e)
        {

        }
        // container for player information
        public class PlayerObject
        {
            public string playerName = string.Empty;
            public int ID = 0;
            public List<FactionObject> playerFactions = new List<FactionObject>();
            public int level;

        }
        // faction object for filling faction Dictionary
        [Serializable]
        public class FactionObject
        {
            //I recommend having two names: a short name String like "Arcea" and a fullname String like "Republic of Arcea"
            private string factionName = string.Empty;
            private String playerName = string.Empty;
            private int espionage = 0;
            private int diplomacy = 0;
            private int mechanized = 0;
            private int armoured = 0;
            private int airAssault = 0;
            private int airCav = 0;
            private int airSuper = 0;
            private int airSupport = 0;
            private int overall = 0; //actual rating of faction tier
            private float progress = 0.0f; //verbose rating of faction tier

            public FactionObject(String name, String play, int esp, int dip, int mec, int arm, int assault, int cav, int super, int support)
            {
                factionName = name;
                playerName = player;
                espionage = esp;
                diplomacy = dip;
                mechanized = mec;
                armoured = arm;
                airAssault = assault;
                airCav = cav;
                airSuper = super;
                airSupport = support;
                SetFactionOverall(); //sets progress and overall
            }
            public void SetFactionOverall()
            {
                float tempOverall = (airAssault + airCav + airSuper + airSupport + armoured + diplomacy + espionage + mechanized) / 8;
                int floor1 = (int)Math.Floor(tempOverall); //casting to int will round this float- Peng
                progress = tempOverall;
                overall = floor1;
            }
            public String getName()
            {
                return factionName;
            }
            public int getEspionage()
            {
                return espionage;
            }
            public String getPlayerId()
            {
                return playerName;
            }
            public int getMechanized()
            {
                return mechanized;
            }
            public int getDiplomacy()
            {
                return diplomacy;
            }
            public int getArmoured()
            {
                return armoured;
            }
            public int getAirAssault()
            {
                return airAssault;
            }
            public int getAirCav()
            {
                return airCav;
            }
            public int getAirSuper()
            {
                return airSuper;
            }
            public int getAirSupport()
            {
                return airSupport;
            }
            public int getOverall()
            {
                return overall;
            }
            public float getProgress()
            {
                return progress;
            }
            public void setEspionage(int input) //no setter for name
            {
                espionage = input;
            }
            public void setPlayerId(int input)
            {
                espionage = input;
            }
            public void setDiplomacy(int input)
            {
                diplomacy = input;
            }
            public void setMechanized(int input)
            {
                mechanized = input;
            }
            public void setArmoured(int input)
            {
                armoured = input;
            }
            public void setAirCav(int input)
            {
                airCav = input;
            }
            public void setAirSuper(int input)
            {
                airSuper = input;
            }
            public void setAirAssault(int input)
            {
                airAssault = input;
            }
            public void setAirSupport(int input)
            {
                airSupport = input;
            }

            //recommend a method for printing the faction-Peng
        }
        public void CheckFile()
        {
            // checks if faction file exists
            string curFile = @"../../../Files/factions.bin";
            if (File.Exists(curFile) == true)
            {
                GenerateFactionDictionary();
                GenerateFactionFile();
            }
        }

        private void GenerateFactionDictionary() //temporary and private
        {
            int i = 0;
            ListOfFactions.Add(i, new FactionObject("Allerod Tribes", "dummy" , 0, 1, 1, 0, 0, 0, 0, 0)); //MOVED THIS HERE
            i++;
            ListOfFactions.Add(i, new FactionObject("Arcean Republic", "dummy", 0, 1, 1, 0, 0, 0, 0, 0)); //fill values yourself- see constructor, DON'T FORGET "PLAYER" (not case sensitive)
            i++;
            ListOfFactions.Add(i, new FactionObject("Confederacy of Cambria", "dummy", 0, 1, 1, 0, 0, 0, 0, 0));
            i++;
            ListOfFactions.Add(i, new FactionObject("Soverign Kingdom of Dahomey", "Ravajava", 0, 1, 1, 0, 0, 0, 0, 0)); //actual name may vary
            i++;
            ListOfFactions.Add(i, new FactionObject("Crown of Dotha", "dummy", 0, 1, 1, 0, 0, 0, 0, 0));
            i++;
            ListOfFactions.Add(i, new FactionObject("Republic of Enshaw", "dummy", 0, 1, 1, 0, 0, 0, 0, 0));
            i++;
            ListOfFactions.Add(i, new FactionObject("United Provinces of Ephesus", "dummy", 0, 1, 1, 0, 0, 0, 0, 0));
            i++;
            ListOfFactions.Add(i, new FactionObject("Hoffnung Restoration Army", "dummy", 0, 1, 1, 0, 0, 0, 0, 0));
            i++;
            ListOfFactions.Add(i, new FactionObject("Khanlinate of Hijjia", "Ravajava", 0, 1, 1, 0, 0, 0, 0, 0));
            i++;
            ListOfFactions.Add(i, new FactionObject("Grand Dutchy of Imania", "dummy", 0, 1, 1, 0, 0, 0, 0, 0));
            i++;
            ListOfFactions.Add(i, new FactionObject("Karelian Empire", "dummy", 1, 0, 1, 0, 0, 0, 0, 0));
            i++;
            ListOfFactions.Add(i, new FactionObject("Kingdom of Martianas", "dummy", 0, 1, 1, 0, 0, 0, 0, 0));
            i++;
            ListOfFactions.Add(i, new FactionObject("Mayayore", "dummy", 1, 0, 1, 0, 0, 0, 0, 0));
            i++;
            ListOfFactions.Add(i, new FactionObject("Kingdom of North Gurrkha", "Penguinpyro", 0, 1, 1, 0, 0, 0, 0, 0));
            i++;
            ListOfFactions.Add(i, new FactionObject("Orissca", "dummy", 1, 1, 0, 0, 0, 0, 0, 0));
            i++;
            ListOfFactions.Add(i, new FactionObject("Kingdom of Seabring", "Galacticvikings", 0, 1, 1, 0, 0, 0, 0, 0));
            i++;
            ListOfFactions.Add(i, new FactionObject("Empire of South Arcea", "Ravajava", 0, 1, 1, 0, 0, 0, 0, 0));
            i++;
            ListOfFactions.Add(i, new FactionObject("United Scarabeen", "Penguinpyro", 1, 0, 1, 0, 0, 0, 0, 0)); //changed faction name
            i++;
            ListOfFactions.Add(i, new FactionObject("Shirudo Kokunate", "dummy", 1, 0, 1, 0, 0, 0, 0, 0));
            i++;
            ListOfFactions.Add(i, new FactionObject("White Forest Confederation", "dummy", 0, 1, 1, 0, 0, 0, 0, 0));
            i++;
            ListOfFactions.Add(i, new FactionObject("Hoffnung Rebels", "dummy", 1, 0, 1, 0, 0, 0, 0, 0));
            i++;
            ListOfFactions.Add(i, new FactionObject("Republic of Aztlan", "GalacticVikings", 1, 0, 1, 0, 0, 0, 0, 0));
            i++;
            ListOfFactions.Add(i, new FactionObject("Otomie Empire", "dummy", 1, 0, 1, 0, 0, 0, 0, 0));
            i++;
            ListOfFactions.Add(i, new FactionObject("Quadruple Alliance", "dummy", 1, 0, 1, 0, 0, 0, 0, 0));
            i++;
        }

        // this function decides which players view to generate
        // if I was smart, I would have organized the factions by player instead of alphabetically so I could just use an iterator...DID THIS FOR YOU-peng
        public void GeneratePlayerList(int aID, string aName)
        {
            PlayerObject newPlayer = new PlayerObject();
            ListViewItem item = new ListViewItem();
            int x = 0;
           //I assume you already have functions for making sure a login is successful and that each name is protected/exclusive- Peng

                for (int i = 0; i < ListOfFactions.Count; i++) //search all factions
                {
                    if (ListOfFactions[i].getPlayerId().ToLower().Equals(aName)) ////add all factions found that have the corresponding player . Not case sensitive, but is whitespace-sensitive.
                    {
                        newPlayer.playerFactions[x] = ListOfFactions[i]; //added matched faction to player list.
                       
                        item.Text = newPlayer.playerName; //initialize faction
                        item.SubItems.Add(newPlayer.playerFactions[x].getName());
                        item.SubItems.Add(newPlayer.playerFactions[x].getOverall().ToString());

                    //I recommend putting a feedback message here saying which faction was added!
                    x++; //iterate for next faction on player list, if multiple factions in this player
                    }
                    //if not found, do nothing, iterate again
                }


            }
            

        
        public void GenerateFactionFile()
        {
            //sets working directory for file creation
            string dir = @"../../../Files";
            string serializationFile = Path.Combine(dir, "factions.bin");
            //serialize
            using (Stream stream = File.Open(serializationFile, FileMode.Create))
            {
                var bformatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
                bformatter.Serialize(stream, ListOfFactions);
            }
        }

    }

}

