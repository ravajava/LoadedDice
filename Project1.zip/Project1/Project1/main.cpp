Vector
#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main()
{
	//vector <int> MyVector;
	//or
	vector <int> MyVector{ 20, 15, 12, 23423, 12, 21, 2 };
	// push item to back of vector
	MyVector.push_back(15);

	vector<int>::iterator Cursor; // 'Cursor' is a pointer to a location inside the vector
	for (Cursor = MyVector.begin(); Cursor != MyVector.end(); Cursor++)
	{
		cout << *Cursor << endl;
	}
	MyVector.resize(2);
	for (Cursor = MyVector.begin(); Cursor != MyVector.end(); Cursor++)
	{
		cout << *Cursor << endl;
	}
	system("PAUSE");
}
vector <int>::iterator Cursor;
Cursor = find(MyVec.begin(), MyVec.end(), 67); // look for 67
MyVec.insert(Cursor, 12); // put 12 at wherever 67 was located

after using the cursor, it must be reset
Cursor = MyVec.begin();

MyVec.erase(Cursor) // will remove whatever element the cursor is currently pointing at