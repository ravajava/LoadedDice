﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace LoadedDice2
{
    
   public enum FACTIONS
    {
        ALLEROD,
        ARCEA,
        AZTLAN,
        CAMBRIA,
        DAHOMEY,
        DOTHA,
        ENSHAW,
        EPHESUS,
        HOFFNUNG_STATE,
        HIJJIA,
        IMANIA,
        KARELIA,
        MARTIANAS,
        MAYAYORE,
        NORTH_GURRKHA,
        ORISSCA,
        SEABRING,
        SOUTH_ARCEA,
        SCARABEEN,
        SHIRUDO,
        WHITE_FOREST,
        WAR_LORD,
        NO_FACTION

    }
    public partial class MainMenu : Form
    {
     
        public Dictionary<int, FactionObject> ListOfFactions = new Dictionary<int, FactionObject>();
        public string pName;
        public MainMenu()
        {
            InitializeComponent();
          
        }
        public MainMenu(string aName)
        {
            InitializeComponent();
            pName = aName;
           
            int i = 0;
            CheckFile();
            //I know that reading from a string file is not preferred, but in this case, it's relatively easy and makes adding new players easier, imo
            foreach (string line in File.ReadLines("../../../Files/users.txt", Encoding.UTF8))
            {

                if (line == pName)
                {
                   
                    GeneratePlayerList(i, pName);
                    break;
                }
                    
                i++;
                
            }
           

        }

         
  
        private void submitButton_Click(object sender, EventArgs e)
        {

        }
        // container for player information
        public class PlayerObject
        {
            public string playerName = string.Empty;
            public int ID = 0;
            public List<FactionObject> playerFactions = new List<FactionObject>();
            public int level;

        }
        // faction object for filling faction Dictionary
        [Serializable]
        public class FactionObject
        {
           
            public string factionName = string.Empty;
            public int espionage = 0;
            public int diplomacy = 0;
            public int mechanized = 0;
            public int armoured = 0;
            public int airAssault = 0;
            public int airCav = 0;
            public int airSuper = 0;
            public int airSupport = 0;
            public float overall = 0.0f;
        }
        public void CheckFile()
        {
            // checks if faction file exists
            string curFile = @"../../../Files/factions.bin";
            if(File.Exists(curFile) == true)
            {
                GenereteFactionDictionary();
                GenerateFactionFile();
            }
        }
        public void GenereteFactionDictionary()
        {
            // I want to murder Penguin. And I'll want to murder myself when I think of a better way to do this...
            FactionObject tempFaction = new FactionObject();
            for(int i = 0; i <= 23; i++)
            {
                if(i == 0)
                {
                    tempFaction.factionName = "Allerod Tribes";
                    tempFaction.espionage = 0;
                    tempFaction.diplomacy = 1;
                    tempFaction.mechanized = 1;
                    tempFaction.armoured = 0;
                    tempFaction.airAssault = 0;
                    tempFaction.airCav = 0;
                    tempFaction.airSuper = 0;
                    tempFaction.airSupport = 0;
                    tempFaction.overall = GetFactionOverall(tempFaction);
                    ListOfFactions.Add(i, tempFaction);


                }
                else if (i == 1)
                {
                    tempFaction.factionName = "Arcean Republic";
                    tempFaction.espionage = 5;
                    tempFaction.diplomacy = 6;
                    tempFaction.mechanized = 7;
                    tempFaction.armoured = 6;
                    tempFaction.airAssault = 8;
                    tempFaction.airCav = 6;
                    tempFaction.airSuper = 9;
                    tempFaction.airSupport = 7;
                    tempFaction.overall = GetFactionOverall(tempFaction);
                    ListOfFactions.Add(i, tempFaction);
                }
                else if (i == 2)
                {
                    tempFaction.factionName = "Confederacy of Cambria";
                    tempFaction.espionage = 2;
                    tempFaction.diplomacy = 7;
                    tempFaction.mechanized = 5;
                    tempFaction.armoured = 3;
                    tempFaction.airAssault = 4;
                    tempFaction.airCav = 3;
                    tempFaction.airSuper = 5;
                    tempFaction.airSupport = 6;
                    tempFaction.overall = GetFactionOverall(tempFaction);
                    ListOfFactions.Add(i, tempFaction);
                }
                else if (i == 3)
                {
                    tempFaction.factionName = "Soverign Kingdom of Dahomey";
                    tempFaction.espionage = 2;
                    tempFaction.diplomacy = 2;
                    tempFaction.mechanized = 3;
                    tempFaction.armoured = 2;
                    tempFaction.airAssault = 2;
                    tempFaction.airCav = 3;
                    tempFaction.airSuper = 4;
                    tempFaction.airSupport = 5;
                    tempFaction.overall = GetFactionOverall(tempFaction);
                    ListOfFactions.Add(i, tempFaction);
                }
                else if (i == 4)
                {
                    tempFaction.factionName = "Crown of Dotha";
                    tempFaction.espionage = 3;
                    tempFaction.diplomacy = 2;
                    tempFaction.mechanized = 4;
                    tempFaction.armoured = 2;
                    tempFaction.airAssault = 4;
                    tempFaction.airCav = 2;
                    tempFaction.airSuper = 3;
                    tempFaction.airSupport = 4;
                    tempFaction.overall = GetFactionOverall(tempFaction);
                    ListOfFactions.Add(i, tempFaction);
                }
                else if (i == 5)
                {
                    tempFaction.factionName = "Republic of Enshaw";
                    tempFaction.espionage = 3;
                    tempFaction.diplomacy = 4;
                    tempFaction.mechanized = 5;
                    tempFaction.armoured = 4;
                    tempFaction.airAssault = 6;
                    tempFaction.airCav = 5;
                    tempFaction.airSuper = 6;
                    tempFaction.airSupport = 7;
                    tempFaction.overall = GetFactionOverall(tempFaction);
                    ListOfFactions.Add(i, tempFaction);
                }
                else if (i == 6)
                {
                    tempFaction.factionName = "United Provinces of Ephesus";
                    tempFaction.espionage = 3;
                    tempFaction.diplomacy = 4;
                    tempFaction.mechanized = 3;
                    tempFaction.armoured = 2;
                    tempFaction.airAssault = 3;
                    tempFaction.airCav = 4;
                    tempFaction.airSuper = 3;
                    tempFaction.airSupport = 5;
                    tempFaction.overall = GetFactionOverall(tempFaction);
                    ListOfFactions.Add(i, tempFaction);
                }
                else if (i == 7)
                {
                    tempFaction.factionName = "Hoffnung Restoration Army";
                    tempFaction.espionage = 1;
                    tempFaction.diplomacy = 2;
                    tempFaction.mechanized = 2;
                    tempFaction.armoured = 3;
                    tempFaction.airAssault = 2;
                    tempFaction.airCav = 3;
                    tempFaction.airSuper = 2;
                    tempFaction.airSupport = 2;
                    tempFaction.overall = GetFactionOverall(tempFaction);
                    ListOfFactions.Add(i, tempFaction);
                }
                else if (i == 8)
                {
                    tempFaction.factionName = "Khanlinate of Hijjia";
                    tempFaction.espionage = 2;
                    tempFaction.diplomacy = 1;
                    tempFaction.mechanized = 5;
                    tempFaction.armoured = 4;
                    tempFaction.airAssault = 2;
                    tempFaction.airCav = 4;
                    tempFaction.airSuper = 2;
                    tempFaction.airSupport = 5;
                    tempFaction.overall = GetFactionOverall(tempFaction);
                    ListOfFactions.Add(i, tempFaction);
                }
                else if (i == 9)
                {
                    tempFaction.factionName = "Grand Dutchy of Imania";
                    tempFaction.espionage = 7;
                    tempFaction.diplomacy = 5;
                    tempFaction.mechanized = 3;
                    tempFaction.armoured = 3;
                    tempFaction.airAssault = 4;
                    tempFaction.airCav = 3;
                    tempFaction.airSuper = 3;
                    tempFaction.airSupport = 3;
                    tempFaction.overall = GetFactionOverall(tempFaction);
                    ListOfFactions.Add(i, tempFaction);
                }
                else if (i == 10)
                {
                    tempFaction.factionName = "Karelian Empire";
                    tempFaction.espionage = 7;
                    tempFaction.diplomacy = 3;
                    tempFaction.mechanized = 6;
                    tempFaction.armoured = 7;
                    tempFaction.airAssault = 7;
                    tempFaction.airCav = 8;
                    tempFaction.airSuper = 7;
                    tempFaction.airSupport = 9;
                    tempFaction.overall = GetFactionOverall(tempFaction);
                    ListOfFactions.Add(i, tempFaction);
                }
                else if (i == 11)
                {
                    tempFaction.factionName = "Kingdom of Martianas";
                    tempFaction.espionage = 3;
                    tempFaction.diplomacy = 2;
                    tempFaction.mechanized = 2;
                    tempFaction.armoured = 1;
                    tempFaction.airAssault = 5;
                    tempFaction.airCav = 2;
                    tempFaction.airSuper = 1;
                    tempFaction.airSupport = 3;
                    tempFaction.overall = GetFactionOverall(tempFaction);
                    ListOfFactions.Add(i, tempFaction);
                }
                else if (i == 12)
                {
                    tempFaction.factionName = "Mayayore";
                    tempFaction.espionage = 5;
                    tempFaction.diplomacy = 3;
                    tempFaction.mechanized = 5;
                    tempFaction.armoured = 4;
                    tempFaction.airAssault = 5;
                    tempFaction.airCav = 2;
                    tempFaction.airSuper = 2;
                    tempFaction.airSupport = 5;
                    tempFaction.overall = GetFactionOverall(tempFaction);
                    ListOfFactions.Add(i, tempFaction);
                }
                else if (i == 13)
                {
                    tempFaction.factionName = "Kingdom of North Gurrkha";
                    tempFaction.espionage = 5;
                    tempFaction.diplomacy = 8;
                    tempFaction.mechanized = 5;
                    tempFaction.armoured = 6;
                    tempFaction.airAssault = 6;
                    tempFaction.airCav = 2;
                    tempFaction.airSuper = 6;
                    tempFaction.airSupport = 5;
                    tempFaction.overall = GetFactionOverall(tempFaction);
                    ListOfFactions.Add(i, tempFaction);
                }
                else if (i == 14)
                {
                    tempFaction.factionName = "Orissca";
                    tempFaction.espionage = 2;
                    tempFaction.diplomacy = 5;
                    tempFaction.mechanized = 4;
                    tempFaction.armoured = 3;
                    tempFaction.airAssault = 5;
                    tempFaction.airCav = 1;
                    tempFaction.airSuper = 3;
                    tempFaction.airSupport = 4;
                    tempFaction.overall = GetFactionOverall(tempFaction);
                    ListOfFactions.Add(i, tempFaction);
                }
  
                else if (i == 15)
                {
                    tempFaction.factionName = "Kingdom of Seabring";
                    tempFaction.espionage = 2;
                    tempFaction.diplomacy = 3;
                    tempFaction.mechanized = 4;
                    tempFaction.armoured = 3;
                    tempFaction.airAssault = 6;
                    tempFaction.airCav = 4;
                    tempFaction.airSuper = 4;
                    tempFaction.airSupport = 5;
                    tempFaction.overall = GetFactionOverall(tempFaction);
                    ListOfFactions.Add(i, tempFaction);
                }
                else if (i == 16)
                {
                    tempFaction.factionName = "Empire of South Arcea";
                    tempFaction.espionage = 5;
                    tempFaction.diplomacy = 2;
                    tempFaction.mechanized = 5;
                    tempFaction.armoured = 8;
                    tempFaction.airAssault = 7;
                    tempFaction.airCav = 4;
                    tempFaction.airSuper = 7;
                    tempFaction.airSupport = 6;
                    tempFaction.overall = GetFactionOverall(tempFaction);
                    ListOfFactions.Add(i, tempFaction);
                }
                else if (i == 17)
                {
                    tempFaction.factionName = "Scarabeen";
                    tempFaction.espionage = 1;
                    tempFaction.diplomacy = 1;
                    tempFaction.mechanized = 3;
                    tempFaction.armoured = 2;
                    tempFaction.airAssault = 2;
                    tempFaction.airCav = 1;
                    tempFaction.airSuper = 1;
                    tempFaction.airSupport = 3;
                    tempFaction.overall = GetFactionOverall(tempFaction);
                    ListOfFactions.Add(i, tempFaction);
                }
                else if (i == 18)
                {
                    tempFaction.factionName = "Shirudo Kokunate";
                    tempFaction.espionage = 4;
                    tempFaction.diplomacy = 9;
                    tempFaction.mechanized = 6;
                    tempFaction.armoured = 5;
                    tempFaction.airAssault = 9;
                    tempFaction.airCav = 6;
                    tempFaction.airSuper = 4;
                    tempFaction.airSupport = 8;
                    tempFaction.overall = GetFactionOverall(tempFaction);
                    ListOfFactions.Add(i, tempFaction);
                }
                else if (i == 19)
                {
                    tempFaction.factionName = "White Forest Confederation";
                    tempFaction.espionage = 5;
                    tempFaction.diplomacy = 7;
                    tempFaction.mechanized = 5;
                    tempFaction.armoured = 4;
                    tempFaction.airAssault = 6;
                    tempFaction.airCav = 2;
                    tempFaction.airSuper = 4;
                    tempFaction.airSupport = 6;
                    tempFaction.overall = GetFactionOverall(tempFaction);
                    ListOfFactions.Add(i, tempFaction);
                }
                else if (i == 20)
                {
                    tempFaction.factionName = "Hoffnung Rebels";
                    tempFaction.espionage = 1;
                    tempFaction.diplomacy = 1;
                    tempFaction.mechanized = 3;
                    tempFaction.armoured = 2;
                    tempFaction.airAssault = 2;
                    tempFaction.airCav = 1;
                    tempFaction.airSuper = 2;
                    tempFaction.airSupport = 5;
                    tempFaction.overall = GetFactionOverall(tempFaction);
                    ListOfFactions.Add(i, tempFaction);
                }
                else if (i == 21)
                {
                    tempFaction.factionName = "Republic of Aztlan";
                    tempFaction.espionage = 2;
                    tempFaction.diplomacy = 1;
                    tempFaction.mechanized = 6;
                    tempFaction.armoured = 2;
                    tempFaction.airAssault = 2;
                    tempFaction.airCav = 4;
                    tempFaction.airSuper = 2;
                    tempFaction.airSupport = 5;
                    tempFaction.overall = GetFactionOverall(tempFaction);
                    ListOfFactions.Add(i, tempFaction);
                }
                else if (i == 22)
                {
                    tempFaction.factionName = "Otomie Empire";
                    tempFaction.espionage = 1;
                    tempFaction.diplomacy = 5;
                    tempFaction.mechanized = 2;
                    tempFaction.armoured = 1;
                    tempFaction.airAssault = 1;
                    tempFaction.airCav = 3;
                    tempFaction.airSuper = 3;
                    tempFaction.airSupport = 5;
                    tempFaction.overall = GetFactionOverall(tempFaction);
                    ListOfFactions.Add(i, tempFaction);
                }
                else if (i == 23)
                {
                    tempFaction.factionName = "Quadruple Alliance";
                    tempFaction.espionage = 3;
                    tempFaction.diplomacy = 6;
                    tempFaction.mechanized = 4;
                    tempFaction.armoured = 1;
                    tempFaction.airAssault = 1;
                    tempFaction.airCav = 1;
                    tempFaction.airSuper = 1;
                    tempFaction.airSupport = 2;
                    tempFaction.overall = GetFactionOverall(tempFaction);
                    ListOfFactions.Add(i, tempFaction);
                }
                //after each iteration, a faction is added to the faction dictionary, titled list of factions. 
                // bite me if you don't like the name, it's my profs naming convention
                
             
            }
         
          
        }
        
        // this fuction decides which players view to generate
        // if I was smart, I would have organized the factions by player instead of alphabetically so I could just use an iterator...
        public void GeneratePlayerList(int aID, string aName)
        {
            PlayerObject newPlayer = new PlayerObject();
            ListViewItem item = new ListViewItem();
            if (aID == 0)
            {

                for (int x = 0; x < 4; x++)
                {
                    if (x == 0)
                    {
                        newPlayer.playerFactions[x] = ListOfFactions[1];
                        item.Text = newPlayer.playerName;
                        item.SubItems.Add(newPlayer.playerFactions[x].factionName);
                        item.SubItems.Add(GetFactionOverall(newPlayer.playerFactions[x]).ToString());
                    }
                    else if (x == 1)
                    {
                        newPlayer.playerFactions[x] = ListOfFactions[5];
                        item.Text = newPlayer.playerName;
                        item.SubItems.Add(newPlayer.playerFactions[x].factionName);
                        item.SubItems.Add(GetFactionOverall(newPlayer.playerFactions[x]).ToString());
                    }
                    else if (x == 2)
                    {
                        newPlayer.playerFactions[x] = ListOfFactions[10];
                        item.Text = newPlayer.playerName;
                        item.SubItems.Add(newPlayer.playerFactions[x].factionName);
                        item.SubItems.Add(GetFactionOverall(newPlayer.playerFactions[x]).ToString());
                    }
                    else if (x == 3)
                    {
                        newPlayer.playerFactions[x] = ListOfFactions[19];
                        item.Text = newPlayer.playerName;
                        item.SubItems.Add(newPlayer.playerFactions[x].factionName);
                        item.SubItems.Add(GetFactionOverall(newPlayer.playerFactions[x]).ToString());
                    }

                }


            }
            else if (aID == 1)
            {
                for (int x = 0; x < 1; x++)
                {
                    if (x == 0)
                    {
                        newPlayer.playerFactions[x] = ListOfFactions[21];
                        item.Text = newPlayer.playerName;
                        item.SubItems.Add(newPlayer.playerFactions[x].factionName);
                        item.SubItems.Add(GetFactionOverall(newPlayer.playerFactions[x]).ToString());
                    }
                    else if (x == 1)
                    {
                        newPlayer.playerFactions[x] = ListOfFactions[15];
                        item.Text = newPlayer.playerName;
                        item.SubItems.Add(newPlayer.playerFactions[x].factionName);
                        item.SubItems.Add(GetFactionOverall(newPlayer.playerFactions[x]).ToString());
                    }
                }
            } else if (aID == 2)
            {

            }

        }
        public void GenerateFactionFile()
        {
            //sets working directory for file creation
            string dir = @"../../../Files";
            string serializationFile = Path.Combine(dir, "factions.bin");
            //serialize
            using (Stream stream = File.Open(serializationFile, FileMode.Create))
            {
                var bformatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
                bformatter.Serialize(stream, ListOfFactions);
            }
        }
        public int GetFactionOverall(FactionObject aFaction)
        {
           float tempOverall = (aFaction.airAssault + aFaction.airCav + aFaction.airSuper + aFaction.airSupport + aFaction.armoured + aFaction.diplomacy + aFaction.espionage + aFaction.mechanized) / 8;
            float floor1 = (float)Math.Floor(tempOverall);
            int rounded = (int)floor1;
            return rounded;
        }
    }
}
